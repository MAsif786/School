<?php 
	include ("../model/connect.php");

$cmID=$_COOKIE['cmID'];
$id = $_GET['id'];

$sql = "SELECT * FROM student WHERE stdID='$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>";
echo "<thead><tr><th>Sr.#</th><th>Roll #</th><th>Name</th><th>Father Name</th><th>Contact</th><th>Address</th><th>Status</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Action</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["stdID"]."</td><td>".$row["stdRollNo"]."</td><td><a href='model/std_profile.php?id=". $row['stdID'] ."'>".$row["stdName"]."</td><td>".$row["stdFather"]."</td><td>".$row["stdContactHome"]."</td><td>".$row["stdAddress"]."</td><td>".$row["stdStatus"]."</td><td><a style='padding-left:20px; padding-right:20px;' class='btn btn-primary' href='edit.php? url=student.php && query=student WHERE stdID=".$row["stdID"]." && check=student'>Edit</a> <hr style='margin:5px;'> <a class='btn btn-danger' href='model/delete.php?query= student WHERE stdID = ".$row["stdID"]." && address=../student.php'>Delete</a></td></td></tr>";
    }

echo "</tbody></table>";

} else {
    echo "<div class='alert alert-info'>
  <strong>Info ! </strong> Not Record Found .
</div> ";
}
$conn->close();

 ?>