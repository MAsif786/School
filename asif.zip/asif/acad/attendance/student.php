<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<title>Attendance System</title>
</head>
<body style="background-color: whitesmoke;">

<div class="container-fluid">
	<div class="row"  style="padding: 30px !important; background: black; color: white ">
		<div class="col-sm-12">
			<div class="pull-left">
				<h1>
					<?php include "../model/cmName.php"; ?>
				</h1>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12" style="text-align: center; ">
			
		</div>
	</div>

	<div class="row" style="padding-top: 120px; ">
		<div class="col-sm-3"></div>
		<div class="col-sm-9">
		<div class="row">
		<h1 class="panel-heading">
					Student Attendance
					 </h1>
						<div class="col-sm-6">
						<div class="form-group">
						<form action="attendS.php" method="post">
							<input class="form-control" type="text" name="code" autofocus>
							<?php if ($_SERVER["REQUEST_METHOD"] == "POST") {
								# code...
								$error = $_GET['error'];
								if ( $error == "1" ) {
									# code...
									echo "<label>NO! Student Recode Found </label>";
								}
							} ?>
							
						</form>
						</div>
						</div>
						<div class="col-sm-6">
							<span class="btn btn-success">/|\</span>
						</div>
		</div>
		</div>
	</div>
</div>

<div class="footer" style="background-color: black; width: 100%; position: absolute; bottom: 0; font-family: sans-serif; text-transform: uppercase; padding: 10px; height: 50px;">
	<label class="pull-right" style="color: white;" href="#"><span style="color: #2ba5ff !important;">Academia</span>Admin</label>
</div>

</body>
</html>