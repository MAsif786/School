<?php

include '../model/connect.php';

date_default_timezone_set("Asia/Karachi");

$date = date('Y-m-d');
$time = date('H:i:s');
echo $time;
$cmID = $_COOKIE['cmID'];

$code = $_POST['code'];
$id = '';

$sql = "SELECT * FROM staff WHERE stCode='$code'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    

    while($row = $result->fetch_assoc()) {
         $id = $row['stID'];
        echo $row['stName'];
    }

} else {
    header("LOCATION: index.php?error=1");
}
$conn->close();


 ?>

<?php 

include '../model/connect.php';

$attendance = "";

$sql = "SELECT * FROM tcattendance WHERE tcID='$id' AND tatdate='$date'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    

    while($row = $result->fetch_assoc()) {
         $attendance = $row['attendance'];
         echo "DB".$attendance."<br>".$row["tcID"];
    }

} else {

	$attendance = "1";
	echo "STATUS".$attendance;
}
$conn->close();


 ?>


<?php 

include '../model/connect.php';

	if ( $attendance == "1") {
		# code...
		$sql = "INSERT INTO tcattendance ( tcID, attendance, tatdate, tatTime, cmID)
	VALUES ( '$id', '0', '$date', '$time', '$cmID' )";
	} elseif ( $attendance == "0") {
		# code...
		$sql = "INSERT INTO tcattendance ( tcID, attendance, tatdate, tatTime, cmID)
	VALUES ( '$id', '1', '$date', '$time', '$cmID' )";
	}
	


if ($conn->query($sql) === TRUE) {

	echo $attendance;

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    
}

$conn->close();



 ?>