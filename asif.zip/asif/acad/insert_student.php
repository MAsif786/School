<?php 
include ("model/connect.php");
include 'document/student/upload.php';
$cmID = $_COOKIE['cmID'];

$crsID = $_POST['crsID'];

$stdRollNo = $_POST['stdRollNo'];

$stdAdmissDate = $_POST['stdAdmissDate'];
$stdName = $_POST['stdName'];
$stdFather = $_POST['stdFather'];
$stdDOB = $_POST['stdDOB'];
$stdCNIC = $_POST['stdCNIC'];
$stdAddress = $_POST['stdAddress'];
$stdContactP = $_POST['stdContactP'];
$stdContactHome = $_POST['stdContactHome'];
$stdFees = $_POST['stdFees'];
$stdRef = $_POST['stdRef'];
$stdStatus = "Enrolled";

$sql = "INSERT INTO student (crsID, stdRollNo, stdAdmissionDate, stdName, stdFather, stdDOB, stdCNIC, stdAddress, stdContactP, stdContactHome, stdFees, stdDocument, stdRef,  stdStatus, cmID)
VALUES ( '$crsID', '$stdRollNo', '$stdAdmissDate', '$stdName', '$stdFather', '$stdDOB', '$stdCNIC', '$stdAddress', '$stdContactP', '$stdContactHome', '$stdFees', '$stdDocument', '$stdRef', '$stdStatus', $cmID)";

if ($conn->query($sql) === TRUE) {
	$conn->close ();
	header("Location:../student.php");
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    
}

$conn->close ();

?>