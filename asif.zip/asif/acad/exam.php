<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
					<div class="panel-heading">Add Exam</div>
					<div class="panel-body">
						<form action="model/insert_exam.php" method="post">

								<div class="row">
									<div class="col-sm-6">
									<div class="form-group">
										<label>Exam Name</label>
										<input class="form-control" placeholder="Exam Name" name="exmName" autofocus required>
									</div>
									</div>
									<div class="col-sm-6">
									<div class="form-group">
										<label>Exam Start Date</label>
										<input type="date" class="form-control" placeholder="Exame Date" name="exmDate" required>
									</div>	
									</div>
								</div>
								<div class="row">
									
									<div class="col-sm-12">
									<input type="submit" class="btn btn-primary" value="Submit">
									<button type="reset" class="btn btn-default">Reset Button</button>
								</div>
								</div>

						</form>
					</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Exam List</div>
					<div class="panel-body">
					<?php include 'model/exam_list.php'; ?>
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>