<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
					<div class="panel-heading"><?php echo"Campus Name Here";?>, <?php echo "Campus City"?></div>
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-4">
								Campus Name: <?php echo "";?>
							</div>
						</div>
					</div>
		</div>
		<div class="panel panel-default">
					<div class="panel-heading"><?php echo"Campus Name Here";?> Staff</div>
					<div class="panel-body">
						tets
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>