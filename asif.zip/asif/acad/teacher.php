<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
					<div class="panel-heading">Add New Course</div>
					<div class="panel-body">
						<form action="model/insert_course.php" method="post">

								<div class="row">
									<div class="col-sm-6">
									<div class="form-group">
										<input class="form-control" placeholder="Course Code" name="crsCode" autofocus>
									</div>
									</div>
									<div class="col-sm-6">
									<div class="form-group">
										<input class="form-control" placeholder="Course Name" name="crsName">
									</div>	
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" type="text" name="tcID" placeholder="Teacher ID">
										</div>
									</div>
									<div class="col-sm-6">
									<input type="submit" class="btn btn-primary" value="Submit">
									<button type="reset" class="btn btn-default">Reset Button</button>
								</div>
								</div>

						</form>
					</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Courses List</div>
					<div class="panel-body">
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>