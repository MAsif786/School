<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
					<div class="panel-heading">Add Test</div>
					<div class="panel-body">
						<form action="model/insert_test.php?id=<?php echo $_GET['id']; ?>" method="post">
								<div class="row">
									<div class="col-sm-6">
									<div class="form-group">
										<label>Select Teacher</label>
										<?php include 'model/select/teacher.php'; ?>
									</div>
									</div>
									<div class="col-sm-6">
									<div class="form-group">
										<label>Select Course</label>
										<?php include 'model/select/course.php'; ?>
									</div>	
									</div>
								</div>

								<div class="row">
									<div class="col-sm-6">
									<div class="form-group">
										<label>Test Subject</label>
										<input class="form-control" placeholder="Test Name" name="tsName" autofocus>
									</div>
									</div>
									<div class="col-sm-6">
									<div class="form-group">
										<label>Test Date</label>
										<input type="date" class="form-control" placeholder="Test Date" name="tsDate">
									</div>	
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
									<div class="form-group">
										<label>Total Marks</label>
										<input type="number" class="form-control" placeholder="Total Marks" name="tsTotalMarks" autofocus>
									</div>
									</div>
									<div class="col-sm-6">
									<div class="form-group pull-right">
										<br>
									<input type="submit" class="btn btn-primary" value="Submit">
									<button type="reset" class="btn btn-default">Reset Button</button>
									</div>	
									</div>
								</div>

						</form>
					</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Test/Subject List</div>
					<div class="panel-body">
					<?php include 'model/test_list.php'; ?>
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>