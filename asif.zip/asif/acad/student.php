<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
			<form action="insert_student.php" method="post" enctype="multipart/form-data">
					<div class="panel-heading">Add Student
					<input id="file" type="file" name="fileToUpload" style="display:none;">
					<label for="file" class="glyphicon glyphicon-picture pull-right img"></label>
					</div>
						<div class="panel-body">
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<?php include 'model/select/course.php'; ?>
											</div>
										</div>
									</div>

									<div class="row">
										
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="Roll #" name="stdRollNo" required>
										</div>	
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" type="date" value="<?php echo $date;?>" name="stdAdmissDate" placeholder="Hire Date" required>
										</div>
										</div>
										
									</div>						
									

									<div class="row">
										
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="Name" name="stdName" required>
										</div>	
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="text" name="stdFather" placeholder="Father Name" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="date" name="stdDOB" placeholder="Date Of Birth" required>
											</div>
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="CNIC" name="stdCNIC" required>
										</div>	
										</div>
									</div>
									<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="Home Contact" name="stdContactHome" required>
										</div>	
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="text" name="stdContactP" placeholder="Personal Contact" >
											</div>
										</div>
										
									</div>
									
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input class="form-control" type="text" name="stdAddress" placeholder="Address" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input class="form-control" type="text" name="stdRef" placeholder="Reference">
											</div>
										</div>
										
									</div>
									<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
										<label>Fees</label>
											<input class="form-control" placeholder="Fess" name="stdFees" required>
										</div>	
										</div>
										<div class="col-sm-6">
											<div class="form-group">
											<label>Status</label>
												<input class="form-control" type="text" name="stdStatus" placeholder="Enrolling" disabled >
											</div>
										</div>
										
									</div>

									<div class="row">
								
										<div class="col-sm-4">
											<input type="submit" class="btn btn-primary" value="Submit">
											<button type="reset" class="btn btn-default">Reset Button</button>
										</div>
									</div>

								</form>
						</div>

						
					</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Staff List</div>
					<div class="panel-body">
					<?php include 'model/student_list.php'; ?>
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>