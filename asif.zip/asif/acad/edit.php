<?php 

include 'files/header.php';
include 'model/connect.php';

$url = $_GET['url'];

$query = $_GET['query'];

$check = $_GET['check'];


$sql = " SELECT * FROM $query ";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

	echo "<br>
	<div class='row'>
		<div class='col-sm-12'>
			<div class='panel panel-default'>
					<div class='panel-heading' style='text-transform:capitalize;'>Edit " . $check . " Detail</div>
					<div class='panel-body'>
						<form action='update.php' method='post'>
						<input type='hidden' name='check' value='".$check."'>";

	while($row = $result->fetch_assoc()) {
if ( $check == "campus") {
	# Campus Edit Form
	echo "	<div class='row'> 	<input type='hidden' name='id' value='". $row['cmID'] ."'>
								<div class='col-sm-4'>
									<div class='form-group'>
										<input class='form-control' value='".$row['cmName']."' name='cmName' placeholder='Campus Name' autofocus required>
									</div>
								</div>
								<div class='col-sm-4'>
									<div class='form-group'>
										<input class='form-control' value='".$row['cmCity']."' name='cmCity'  placeholder='Campus City' required>
									</div>
								</div>
								<div class='col-sm-4'>
									<div class='form-group'>
										<input class='form-control' name='cmEsatablishDate'  value='".$row['cmEsatablishDate']."' required>
									</div>
								</div>
							</div>


							<div class='row'>
								<div class='col-sm-4'>
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input class='form-control' value='".$row['cmContact']."' name='cmContact' placeholder='Campus Contact 1' required>
											</div>
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input class='form-control' value='".$row['cmContact']."' name='cmContact2' placeholder='Campus Contact 2' >
											</div>
										</div>
									</div>
								</div>
								<div class='col-sm-4'>
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input class='form-control' value='".$row['cmContactM']."' name='cmContactM' placeholder='Official Mobile' required>
											</div>
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input type='Email' value='".$row['cmMail']."' class='form-control' name='cmMail' placeholder='Official Email' required>
											</div>
										</div>
									</div>
								</div>
								<div class='col-sm-4'>
									<div class='form-group'>
									<label>Campus Address</label>
									<textarea class='form-control' name='cmAddress' rows='2' required>".$row['cmAddress']."</textarea>
								</div>
								</div>
							</div>

							<div class='row'>
								<div class='col-sm-8'>
									<div class='form-group'>
												<input type='number' value='".$row['cmRoomCount']."' class='form-control' name='cmRoomCount' placeholder='Rooms in Campus' Campus Address>
											</div>
								</div>
								<div class='col-sm-4'>
								</div>
							</div ";


		} elseif ( $check == "staff" ) {
			# Staff Edit Form
			echo "<div class='row'>
										<input type='hidden' name='id' value='". $row['stID'] ."'>
										<div class='col-sm-6'>
										<div class='form-group'>
											<select  class='form-control' name='stDep' required >
												<option selected disabled>Staff Department</option>
												<option value='admin'>Admin</option>
												<option value='teacher'>Teacher</option>
												<option value='clerk'>Clerk</option>
											</select>
										</div>
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' type='date' value='". $row['stHireDate']  ."' name='stHireD' placeholder='Hire Date' required >
										</div>
										</div>
									</div>

									<div class='row'>
										
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' value='". $row['stName'] ."' placeholder='Name' name='stName' required autofocus>
										</div>	
										</div>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input class='form-control' value='". $row['stFather'] ."' type='text' name='stFather' placeholder='Father Name' required>
											</div>
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input class='form-control' value='". $row['stDOB'] ."' type='date' name='stDOB' placeholder='Date Of Birth' required>
											</div>
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' value='". $row['stCNIC'] ."' placeholder='CNIC' name='stCNIC' required>
										</div>	
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input class='form-control' value='". $row['stContactP'] ."' type='text' name='stContactP' placeholder='Personal Contact' required>
											</div>
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' value='". $row['stContactM'] ."' placeholder='Mobile Contact' name='stContactM'>
										</div>	
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input class='form-control' value='". $row['stMailP'] ."' type='email' name='stMailP' placeholder='Personal Email' required>
											</div>
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' value='". $row['stMailO'] ."' type='email' placeholder='Official Email' name='stMailO'>
										</div>	
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input class='form-control' value='". $row['stAddress'] ."' type='text' name='stAddress' placeholder='Address' required>
											</div>
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input class='form-control' value='". $row['stRefName'] ."' type='text' name='stRefName' placeholder='Reference Name'>
											</div>
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' value='". $row['stRefContact'] ."' placeholder='Reference Contact' name='stRefContact'>
										</div>	
										</div>
									</div>";


		} elseif ( $check == "student" ) {
			# Student Edit Form
			echo "<div class='row'>
										<input type='hidden' name='id' value='". $row['stdID'] ."'>
										<div class='col-sm-12'>
											<div class='form-group'>";
												 include 'model/select/course.php'; 
									echo "
											</div>
										</div>
									</div>

									<div class='row'>
										
										<div class='col-sm-6'>
										<div class='form-group'>
											<input class='form-control' value='". $row['stdRollNo'] ."' placeholder='Roll #' name='stdRollNo' required autofocus>
										</div>	
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input value='". $row['stdAdmissDate'] ."' class='form-control' type='date' name='stdAdmissDate' placeholder='Hire Date' required>
										</div>
										</div>
										
									</div>						
									

									<div class='row'>
										
										<div class='col-sm-6'>
										<div class='form-group'>
											<input value='". $row['stdName'] ."' class='form-control' placeholder='Name' name='stdName' required>
										</div>	
										</div>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input value='". $row['stdFather'] ."' class='form-control' type='text' name='stdFather' placeholder='Father Name' required>
											</div>
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input value='". $row['stdDOB'] ."' class='form-control' type='date' name='stdDOB' placeholder='Date Of Birth' required>
											</div>
										</div>
										<div class='col-sm-6'>
										<div class='form-group'>
											<input value='". $row['stdCNIC'] ."' class='form-control' placeholder='CNIC' name='stdCNIC' required>
										</div>	
										</div>
									</div>
									<div class='row'>
									<div class='col-sm-6'>
										<div class='form-group'>
											<input value='". $row['stdContactHome'] ."' class='form-control' placeholder='Home Contact' name='stdContactHome' required>
										</div>	
										</div>
										<div class='col-sm-6'>
											<div class='form-group'>
												<input value='". $row['stdContactP'] ."' class='form-control' type='text' name='stdContactP' placeholder='Personal Contact' >
											</div>
										</div>
										
									</div>
									
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input value='". $row['stdAddress'] ."' class='form-control' type='text' name='stdAddress' placeholder='Address' required>
											</div>
										</div>
									</div>
									<div class='row'>
										<div class='col-sm-12'>
											<div class='form-group'>
												<input value='". $row['stdRef'] ."' class='form-control' type='text' name='stdRef' placeholder='Reference'>
											</div>
										</div>
										
									</div>
									<div class='row'>
									<div class='col-sm-6'>
										<div class='form-group'>
										<label>Fees</label>
											<input value='". $row['stdFees'] ."' class='form-control' placeholder='Fess' name='stdFees' required>
										</div>	
										</div>
										<div class='col-sm-6'>
										</div>
										
									</div>";

		} elseif ( $check == "course" ) {
			# code...
			echo "<div class='row'>
									<input type='hidden' name='id' value='". $row['crsID'] ." '>
									<div class='col-sm-6'>
									<div class='form-group'>
										<input value='". $row['crsCode'] ."' class='form-control' placeholder='Course Code' name='crsCode' autofocus>
									</div>
									</div>
									<div class='col-sm-6'>
									<div class='form-group'>
										<input value='". $row['crsName'] ." ' class='form-control' placeholder='Course Name' name='crsName'>
									</div>	
									</div>
								</div>
								
								<div class='row'>
									<div class='col-sm-12'>
										<div class='form-group'>";

											include 'model/select/teacher.php';
										echo "
										</div>
									</div>
									
								</div>";
		} elseif( $check == "exam" ){

			echo "<div class='row'>
			<input type='hidden' name='id' value='". $row['exmID'] ." '>
									<div class='col-sm-6'>
									<div class='form-group'>
										<label>Exam Name</label>
										<input class='form-control' value='". $row['exmName'] ."' placeholder='Exam Name' name='exmName' autofocus required>
									</div>
									</div>
									<div class='col-sm-6'>
									<div class='form-group'>
										<label>Exam Start Date</label>
										<input type='date' class='form-control' value='". $row['exmDate'] ."' placeholder='Exame Date' name='exmDate' required>
									</div>	
									</div>
								</div>";

		}




	}

	echo "					<div class='row'>
								<div class='col-sm-4'>
									<input type='submit' class='btn btn-primary' value='Submit'>
									<a href='". $url ."' class='btn btn-default'>Cancel</a>
								</div>
							</div></form>
					</div>
		</div>
	</div>
	</div>";

} else{

	echo "ERROR";
}

$conn->close();


include 'files/footer.php';

 ?>