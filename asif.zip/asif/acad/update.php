<?php 
include ("model/connect.php");

$check = $_POST['check'];
$id = $_POST['id'];

if ( $check == "campus" ) {
	# UPDATE CAMPUS..

	$cmName = $_POST['cmName'];
	$cmCity = $_POST['cmCity']; 
	$cmAddress = $_POST['cmAddress'];
	$cmContact = $_POST['cmContact'];
	$cmContact2 = $_POST['cmContact2'];
	$cmContactM = $_POST['cmContactM'];
	$cmMail = $_POST['cmMail'];
	$cmEsatablishDate = $_POST['cmEsatablishDate'];
	$cmRoomCount = $_POST['cmRoomCount'];

	$sql = "UPDATE $check SET cmName='$cmName', cmCity='$cmCity', cmAddress='$cmAddress', cmContact='$cmContact', cmContact2='$cmContact2', cmContactM='$cmContactM', cmMail='$cmMail', cmEsatablishDate='$cmEsatablishDate', cmRoomCount='$cmRoomCount'  WHERE cmID='$id'";

		if ($conn->query($sql) === TRUE) {
		    $conn->close();
		    header("LOCATION: campus.php");

		} else {
		    echo "Error updating record: " . $conn->error;
		}

} elseif ( $check == "staff" ) {
	# UPDATE STAFF...
	$stDep = $_POST['stDep'];
	$stHireD = $_POST['stHireD'];

	$stName = $_POST['stName'];
	$stFather = $_POST['stFather'];

	$stDOB = $_POST['stDOB'];

	$stCNIC = $_POST['stCNIC'];

	$stAddress = $_POST['stAddress'];

	$stContactP = $_POST['stContactP'];
	$stContactM = $_POST['stContactM'];

	$stMailO = $_POST['stMailO'];
	$stMailP = $_POST['stMailP'];

	$stRefName = $_POST['stRefName'];
	$stRefContact = $_POST['stRefContact'];

	$sql  = "UPDATE $check SET stDep='$stDep', stHireDate='$stHireD', stName='$stName', stFather='$stFather', stDOB='$stDOB', stCNIC='$stCNIC', stAddress='$stAddress', stContactP='$stContactP', stContactM='$stContactM', stMailO='$stMailO', stMailP='$stMailP', stRefName='$stRefName', stRefContact='$stRefContact' WHERE stID='$id'  ";

		if ($conn->query($sql) === TRUE) {
		    $conn->close();
		    header("LOCATION: staff.php");

		} else {
		    echo "Error updating record: " . $conn->error;
		}


} elseif ( $check == "student" ) {
	# UPDATE STAFF...
	$crsID = $_POST['crsID'];

	$stdRollNo = $_POST['stdRollNo'];

	$stdAdmissDate = $_POST['stdAdmissDate'];
	$stdName = $_POST['stdName'];
	$stdFather = $_POST['stdFather'];
	$stdDOB = $_POST['stdDOB'];
	$stdCNIC = $_POST['stdCNIC'];
	$stdAddress = $_POST['stdAddress'];
	$stdContactP = $_POST['stdContactP'];
	$stdContactHome = $_POST['stdContactHome'];
	$stdFees = $_POST['stdFees'];
	$stdRef = $_POST['stdRef'];


	$sql  = "UPDATE $check SET crsID='$crsID', stdRollNo='$stdRollNo', stdAdmissionDate='$stdAdmissDate', stdName='$stdName', stdFather='$stdFather', stdDOB='$stdDOB', stdCNIC='$stdCNIC', stdAddress='$stdAddress', stdContactP='$stdContactP', stdContactHome='$stdContactHome', stdFees='$stdFees', stdDocument='$stdDocument', stdRef='$stdRef' WHERE stdID='$id'  ";

		if ($conn->query($sql) === TRUE) {
		    $conn->close();
		    header("LOCATION: student.php");

		} else {
		    echo "Error updating record: " . $conn->error;
		}


} elseif ( $check == "course" ) {
	# UPDATE COURSE...

	$crsCode = $_POST['crsCode'];
	$crsName = $_POST['crsName']; 
	$tcID = $_POST['tcID'];

	$sql = "UPDATE $check SET crsCode='$crsCode', crsName='$crsName', tcID='$tcID' WHERE crsID='$id' ";

	if ($conn->query($sql) === TRUE) {
		    $conn->close();
		    header("LOCATION: course.php");

		} else {
		    echo "Error updating record: " . $conn->error;
		}

} elseif ( $check == "exam" ) {
	# Update Exam

	$exmName = $_POST['exmName'];
	$exmDate = $_POST['exmDate'];


	$sql = "UPDATE $check SET exmName='$exmName', exmDate='$exmDate' WHERE exmID='$id' ";
 

	if ($conn->query($sql) === TRUE) {
		    $conn->close();
		    header("LOCATION: exam.php");

		} else {
		    echo "Error updating record: " . $conn->error;
		}





} 

else {
	echo "string";
}
 


$conn->close ();

?>