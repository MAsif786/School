<?php 
	include ("model/connect.php");

$id = $_GET['id'];
$stdDocument = '';

$sql = "SELECT * FROM student WHERE stdID=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
    	$stdDocument = $row['stdDocument'];
    	$stdName = $row['stdName'];
    	$stdFather = $row['stdFather'];
    	$stdDOB = $row['stdDOB'];
    	$stdRollNo = $row['stdRollNo'];
    }

echo "</tbody></table>";

} else {
    echo "0 results";
}
$conn->close();

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Student Profile</title>

 	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
 </head>
 <body>

	<div class="container-fluid">
 	
 		<div class="row">
 			
 			<div class="col-sm-12""> 
 			
 				<a class="navbar-brand" href="index.php"> <?php include 'model/cmName.php'; ?> </a>
 			
 			</div>

 		</div>

 		<div class="row" style="height: 200px; background-color:; ">

 			
	 		<div class="col-sm-12" style="background-color: ; ">
	 			
	 			<img class="pull-left" src=" <?php echo $stdDocument; ?> " height='200px' width='200px;' >

	 		<div class="pull-left" style=" margin: 40px 0 0 10px;">
 				
	 				<label>Roll Number :</label> <span><?php echo $stdRollNo; ?></span> <br>
	 				<label>Name :</label> <span><?php echo $stdName; ?></span> <br>
	 				<label>Father Name  :</label> <span><?php echo $stdFather; ?></span> <br> 
	 				<label>Date Of Birth :</label> <span><?php echo $stdDOB; ?></span>  
	 			
 			</div>
 			</div>
 			
 		</div>

 		<br>

 		<div class="row" style="border-top: 2px solid gray; border-bottom: 2px solid gray;  ">
 			<div class="col-sm-12">
 			<center>
 				<h1>Marks<span style="color:#2ba5ff;">Sheet</span></h1>
 			</center>
 			</div>
 		</div>

 		<div class="row" style="border-bottom: 2px solid gray; ">
 			<div class="col-sm-12">
	 			<table class="table">
	 				<tbody>
	 				<tr>
	 					<th>Date/Sub.</th><th>Obtain Marks</th><th>Total Marks</th><th>Grade</th>
	 				</tr>
	 				</tbody>
	 				<tr><th>Islamiat</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>Uru</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>Social Study</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>G.K.</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>English</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>Math</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>Sience</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>Physics</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tr><th>Chemistry</th><td>50</td><td>100</td><td>A+</td></tr>
	 				<tbody>
	 				<tr><th>Total</th><th>500</th><th>1000</th><th>A+</th></tr>
	 				</tbody>

	 			</table>
 			</div>
 		</div>

	</div>
 	
 
 </body>
 </html>