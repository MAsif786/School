<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
					<div class="panel-heading">Add Class</div>
					<div class="panel-body">
						<form action="model/insert_course.php" method="post">
								
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<?php include 'model/select/teacher.php'; ?>
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-sm-6">
									<div class="form-group">
										<input class="form-control" placeholder="Class Code" name="crsCode" autofocus>
									</div>
									</div>
									<div class="col-sm-6">
									<div class="form-group">
										<input class="form-control" placeholder="Class Name" name="crsName">
									</div>	
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
									<input type="submit" class="btn btn-primary" value="Submit">
									<button type="reset" class="btn btn-default">Reset Button</button>
								</div>
								</div>

						</form>
					</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Class List</div>
					<div class="panel-body">
					<?php include 'model/course_list.php'; ?>
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>