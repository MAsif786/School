<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="profile.php" method="post">
	<input type="text" name="sub" autofocus>
</form>
</body>
</html>