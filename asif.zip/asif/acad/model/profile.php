<?php 
	include ("connect.php");
$courseCode = $_POST["sub"];
$sql = "SELECT * FROM course where crsCode = '$courseCode';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>";
echo "<thead><tr> <th>Course ID</th><th>Course Code</th><th>Course Name</th><th>Teacher ID</th><th>Status</th><th>Start Date</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["crsID"]."</td><td>".$row["crsCode"]."</td><td>".$row["crsName"]."</td><td>".$row["tcID"]."</td><td>".$row["cmID"]."</td><td></tr>";
    }

echo "</tbody></table>";

} else {
    echo "0 results";
}
$conn->close();

 ?>