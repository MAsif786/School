<?php 
	include ("model/connect.php");

$sql = "SELECT * FROM campus";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>";
echo "<thead><tr> <th>Campus ID</th><th>Campus Name</th><th>Campus City</th><th>Contact</th><th>Address</th><th>E-Mail</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Action</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["cmID"]."</td><td>".$row["cmName"]."</td><td>".$row["cmCity"]."</td><td>".$row["cmContact"]."</td><td>".$row["cmAddress"]."</td><td>".$row["cmMail"]."</td><td><a style='padding-left:20px; padding-right:20px;' class='btn btn-primary' href='edit.php?  url=campus.php && query= campus WHERE cmID =".$row["cmID"]." && check=campus'>Edit</a> <hr style='margin:5px;'> <a class='btn btn-danger' href='model/delete.php?query= campus WHERE cmID = ".$row["cmID"]." && address=../campus.php'>Delete</a></td></tr>";
    }

echo "</tbody></table>";

} else {
    echo "<div class='alert alert-info'>
  <strong>Info ! </strong> Not Record Found .
</div> ";
}
$conn->close();

 ?>