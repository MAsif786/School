<?php 

$error = $_GET['error'];

echo "<h1>". $error ."</h1>";


 ?>