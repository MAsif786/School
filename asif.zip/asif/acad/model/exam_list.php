<?php 
	include ("connect.php");
	$cmID=$_COOKIE['cmID'];
$sql = "SELECT * FROM exam WHERE cmID='$cmID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>
	<form action='exam_close.php method='post'>";
echo "<thead><tr><th></th><th>Exam ID</th><th>Exam Name</th><th>Exam Start From</th><th>Exam Status</th><th>&nbsp;&nbsp;&nbsp;Action</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td><input type='checkbox' value='". $row['exmID'] ."' name='a'></td><td>".$row["exmID"]."</td><td><a href='test.php?id=". $row['exmID'] ."'>".$row["exmName"]."</a></td><td>".$row["exmDate"]."</td><td>".$row["exmStatus"]."</td><td><a style='padding-left:20px; padding-right:20px;' class='btn btn-primary' href='edit.php? url=exam.php && query= exam WHERE exmID =".$row["exmID"]." && check=exam'>Edit</a> <hr style='margin:5px;'> <a class='btn btn-danger' href='model/delete.php?query= Exam WHERE exmID = ".$row["exmID"]." && address=../exam.php'>Delete</a></td></tr>";
    }

echo "</tbody></table><input class='btn btn-primary' type='submit' value='Status Close'></form>";

} else {
    echo "<div class='alert alert-info'>
  <strong>Info ! </strong> Not Record Found .
</div> ";
}
$conn->close();

 ?>