<?php 
include "model/connect.php";
$sql = "SELECT * FROM staff WHERE stDep='teacher' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<select name='tcID' class='form-control' required>";
	echo "<option disabled selected>Select Teacher</option>";
    while($row = $result->fetch_assoc()) {
        echo "<option value='".$row["stID"]."'>".$row["stName"]."</option>";
    }

echo "</select>";

} else {
    echo "No Teachers Added Please First <a href='staff.php'>Add Teacher</a>";
}

?>


