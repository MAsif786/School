<?php 
include ("acad/model/connect.php");
$sql = "SELECT * FROM campus";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<select name='cm' class='form-control' required>";
	echo "<option disabled selected>Select Campus</option>";
    while($row = $result->fetch_assoc()) {
        echo "<option value='".$row["cmID"]."'>".$row["cmName"]."</option>";
    }

echo "</select>";

} else {
    echo "<inpu type='text' class='form-control' placeholder='No Campus Added Yet' disabled>";
}
$conn->close ();

?>


