<?php 
include "model/connect.php";
$sql = "SELECT * FROM course";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<select name='crsID' class='form-control' required>";
	echo "<option disabled selected>Select Class</option>";
    while($row = $result->fetch_assoc()) {
        echo "<option value='".$row["crsID"]."'>".$row["crsName"]."</option>";
    }

echo "</select>";

} else {
    echo "No Course Added Please First <a href='course.php'>Add Course</a>";
}


?>


