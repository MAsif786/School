<?php 
	include ("connect.php");
	
$sql = "SELECT * FROM test";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>";
echo "<thead><tr><th>Test ID</th><th>Test Name</th><th>Test Date</th><th>Test Marks</th><th>&nbsp;&nbsp;&nbsp;Action</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["tsID"]."</td><td>".$row["tsName"]."</td><td>".$row["tsDate"]."</td><td>".$row["tsTotalMarks"]."</td><td><a style='padding-left:20px; padding-right:20px;' class='btn btn-primary' href='edit.php? url=Exam.php && query= Exam WHERE tsID=".$row["tsID"]." && check=Exam'>Edit</a> <hr style='margin:5px;'> <a class='btn btn-danger' href='model/delete.php?query= Exam WHERE crsID = ".$row["tsID"]." && address=../Exam.php'>Delete</a></td></tr>";
    }

echo "</tbody></table>";

} else {
    echo "<div class='alert alert-info'>
  <strong>Info ! </strong> Not Record Found .
</div> ";
}
$conn->close();

 ?>