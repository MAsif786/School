<?php 
include ("connect.php");


$cmID=$_COOKIE['cmID'];

$exmName = $_POST['exmName'];
$exmDate = $_POST['exmDate']; 
$exmStatus = 'Open';

$sql = "INSERT INTO exam (exmName, exmDate, exmStatus, cmID)
VALUES ('$exmName', '$exmDate', '$exmStatus', '$cmID')";

if ($conn->query($sql) === TRUE) {
	$conn->close ();
	header("Location:../test.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    
}

$conn->close();

?>