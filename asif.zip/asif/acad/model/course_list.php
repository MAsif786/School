<?php 
	include ("connect.php");
	$cmID=$_COOKIE['cmID'];
$sql = "SELECT * FROM course WHERE cmID='$cmID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>";
echo "<thead><tr> <th>Class ID</th><th>Class Code</th><th>Class Name</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Action</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["crsID"]."</td><td>".$row["crsCode"]."</td><td>".$row["crsName"]."</td><td><a style='padding-left:20px; padding-right:20px;' class='btn btn-primary' href='edit.php? url=course.php && query= course WHERE crsID=".$row["crsID"]." && check=course'>Edit</a> <hr style='margin:5px;'> <a class='btn btn-danger' href='model/delete.php?query= course WHERE crsID = ".$row["crsID"]." && address=../course.php'>Delete</a></td></tr>";
    }

echo "</tbody></table>";

} else {
    echo "<div class='alert alert-info'>
  <strong>Info ! </strong> Not Record Found .
</div> ";
}
$conn->close();

 ?>