<?php 
	include 'connect.php';

	$query = $_GET['query'];

	$address = $_GET['address'];

	$sql = " DELETE FROM $query ";


	if ($conn->query($sql) === TRUE ) {
		# code...
		$conn->close();
		header("Location: $address");

	} else {

		echo "Check Connection : " . $conn->error;
	}


	$conn->close();



 ?>