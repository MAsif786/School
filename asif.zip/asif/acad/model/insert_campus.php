<?php 
include ("connect.php");


$cmName = $_POST['cmName'];
$cmCity = $_POST['cmCity']; 
$cmAddress = $_POST['cmAddress'];
$cmContact = $_POST['cmContact'];
$cmContact2 = $_POST['cmContact2'];
$cmContactM = $_POST['cmContactM'];
$cmMail = $_POST['cmMail'];
$cmEsatablishDate = $_POST['cmEsatablishDate'];
$cmRoomCount = $_POST['cmRoomCount'];
$cmDocuments = "Test";


$sql = "INSERT INTO campus (cmName, cmCity, cmAddress, cmContact, cmContact2, cmContactM, cmMail, cmEsatablishDate, cmRoomCount, cmDocuments)
VALUES ('$cmName', '$cmCity', '$cmAddress', '$cmContact', '$cmContact2', '$cmContactM', '$cmMail', '$cmEsatablishDate', '$cmRoomCount', '$cmDocuments')";

if ($conn->query($sql) === TRUE) {
	$conn->close ();
	header("Location:../campus.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
   
}
$conn->close ();

?>