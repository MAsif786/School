<?php 
include ("connect.php");

$exmID = $_GET['id'];

$tcID = $_POST['tcID'];

$crsID = $_POST['crsID'];

$tsName = $_POST['tsName'];
$tsDate = $_POST['tsDate'];
$tsTotalMarks = $_POST['tsTotalMarks'];


$sql = "INSERT INTO test ( tsName, tsDate, tsTotalMarks, tcID, crsID, exmID )
VALUES ( '$tsName', '$tsDate', '$tsTotalMarks', '$tcID', '$crsID', '$exmID' )";

if ($conn->query($sql) === TRUE) {

	$conn->close ();
	header("Location:../test.php?id=$exmID");

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
   
}
$conn->close ();

?>