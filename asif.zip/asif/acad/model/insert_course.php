<?php 
include ("connect.php");

$cmID=$_COOKIE['cmID'];

$crsCode = $_POST['crsCode'];
$crsName = $_POST['crsName']; 
$tcID = $_POST['tcID'];


$sql = "INSERT INTO course (crsCode, crsName, tcID, cmID)
VALUES ('$crsCode', '$crsName','$tcID','$cmID')";

if ($conn->query($sql) === TRUE) {
	$conn->close ();
	header("Location:../course.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    
}

$conn->close();

?>