<?php 
	include ("connect.php");


$cmID=$_COOKIE['cmID'];

$sql = "SELECT * FROM staff WHERE cmID='$cmID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
echo "<table class='table table-hover'>";
echo "<thead><tr> <th>Staff ID</th><th>Staff Dep.</th><th>Name</th><th>Father Name</th><th>Contact</th><th>Address</th><th>E-Mail</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Action</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["stID"]."</td><td>".$row["stDep"]."</td><td>".$row["stName"]."</td><td>".$row["stFather"]."</td><td>".$row["stContactP"]."</td><td>".$row["stAddress"]."</td><td>".$row["stMailP"]."</td><td><a style='padding-left:20px; padding-right:20px;' class='btn btn-primary' href='edit.php? url=staff.php && query= staff WHERE stID=".$row["stID"]." && check=staff'>Edit</a> <hr style='margin:5px;'> <a class='btn btn-danger' href='model/delete.php?query= staff WHERE stID = ".$row["stID"]." && address=../staff.php'>Delete</a></td></tr>";
    }

echo "</tbody></table>";

} else {
    echo "<div class='alert alert-info'>
  <strong>Info ! </strong> Not Record Found .
</div> ";
}
$conn->close();

 ?>