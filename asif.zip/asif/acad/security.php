<?php
if (isset($_GET['verify'])) {
	# code...

$verify = $_GET['verify'];

if ( $verify != null) {
	# code...

	setcookie( "cmID", $verify , time() + 36000 );
	
	header("Location: index.php");
}


}

 ?>