<?php
include("files/header.php");

?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
					<div class="panel-heading">Add New Campus</div>
					<div class="panel-body">
						<form action="model/insert_campus.php" method="post">
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<input class="form-control" name="cmName" placeholder="Campus Name" autofocus required>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<input class="form-control" name="cmCity" placeholder="Campus City" required>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<input class="form-control" name="cmEsatablishDate" value="<?php echo date('d-m-Y');?>" required>
									</div>
								</div>
							</div>


							<div class="row">
								<div class="col-sm-4">
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input class="form-control" name="cmContact" placeholder="Campus Contact 1" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input class="form-control" name="cmContact2" placeholder="Campus Contact 2" >
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input class="form-control" name="cmContactM" placeholder="Official Mobile" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input type="Email" class="form-control" name="cmMail" placeholder="Official Email" required>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
									<label>Campus Address</label>
									<textarea class="form-control" name="cmAddress" rows="2" required></textarea>
								</div>
								</div>
							</div>

							<div class="row">
								<div class="col-sm-8">
									<div class="form-group">
												<input type="number" class="form-control" name="cmRoomCount" placeholder="Rooms in Campus" Campus Address>
											</div>
								</div>
								<div class="col-sm-4">
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<input type="submit" class="btn btn-primary" value="Submit">
									<button type="reset" class="btn btn-default">Reset Button</button>
								</div>
							</div>


						</form>
					</div>
		</div>
	</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Campus List</div>
					<div class="panel-body">
						<?php include("model/campus_list.php");?>
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>