<?php 
include ("model/connect.php");
include 'document/staff/upload.php';
$cmID = $_COOKIE['cmID'];

$stDep = $_POST['stDep'];
$stHireD = $_POST['stHireD'];

$stName = $_POST['stName'];
$stFather = $_POST['stFather'];

$stDOB = $_POST['stDOB'];

$stCNIC = $_POST['stCNIC'];

$stAddress = $_POST['stAddress'];

$stContactP = $_POST['stContactP'];
$stContactM = $_POST['stContactM'];

$stMailO = $_POST['stMailO'];
$stMailP = $_POST['stMailP'];

$stRefName = $_POST['stRefName'];
$stRefContact = $_POST['stRefContact'];



$sql = "INSERT INTO staff (stDep, stHireDate, stName, stFather, stDOB, stCNIC, stAddress, stContactP, stContactM, stMailO, stMailP, stDocument, stRefName, stRefContact, cmID)
VALUES ( '$stDep', '$stHireD', '$stName', '$stFather', '$stDOB', '$stCNIC', '$stAddress', '$stContactP', '$stContactM', '$stMailO', '$stMailP', '$stDocument', '$stRefName', '$stRefContact', $cmID)";

if ($conn->query($sql) === TRUE) {

	$con->close();
	header("LOCATION: ../staff.php")
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    
}

$conn->close ();

?>