<?php
include("files/header.php");
?>		<br>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
			<form action="insert_staff.php" method="post" enctype="multipart/form-data">
					<div class="panel-heading">Add Staff 
					<label class="glyphicon glyphicon-picture pull-right btn btn-default btn-file">
    					 <input type="file" name="fileToUpload" style="display: none;" required>
					</label>
					<label class="glyphicon glyphicon-file pull-right btn btn-default btn-file">
    					 <input type="file" name="fileToUpload" style="display: none;" required>
					</label>
					
					</div>
						<div class="panel-body">
							
									<div class="row">
										<div class="col-sm-6">
										<div class="form-group">
											<select  class="form-control" name="stDep" required>
												<option selected disabled>Staff Department</option>
												<option value="admin">Admin</option>
												<option value="teacher">Teacher</option>
												<option value="clerk">Clerk</option>
											</select>
										</div>
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" type="date" value="<?php echo $date;?>" name="stHireD" placeholder="Hire Date" required>
										</div>
										</div>
									</div>

									<div class="row">
										
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="Name" name="stName" required>
										</div>	
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="text" name="stFather" placeholder="Father Name" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="date" name="stDOB" placeholder="Date Of Birth" required>
											</div>
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="CNIC" name="stCNIC" required>
										</div>	
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="text" name="stContactP" placeholder="Personal Contact" required>
											</div>
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="Mobile Contact" name="stContactM">
										</div>	
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="email" name="stMailP" placeholder="Personal Email" required>
											</div>
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" type="email" placeholder="Official Email" name="stMailO">
										</div>	
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<input class="form-control" type="text" name="stAddress" placeholder="Address" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input class="form-control" type="text" name="stRefName" placeholder="Reference Name">
											</div>
										</div>
										<div class="col-sm-6">
										<div class="form-group">
											<input class="form-control" placeholder="Reference Contact" name="stRefContact">
										</div>	
										</div>
									</div>

									<div class="row">
								
										<div class="col-sm-4">
											<input type="submit" class="btn btn-primary" value="Submit">
											<button type="reset" class="btn btn-default">Reset Button</button>
										</div>
									</div>

								</form>
						</div>

						
					</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
					<div class="panel-heading">Staff List</div>
					<div class="panel-body">
					<?php include 'model/staff_list.php'; ?>
					</div>
		</div>
	</div>
<?php
include("files/footer.php");
?>