<?php 
  $camp =  $_POST["cm"];


  if(  $camp != null  )
  {
    setcookie( "cm", $camp , time() + 36000 );
    header("Location:index.php");
  }
?>