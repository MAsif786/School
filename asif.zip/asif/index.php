<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="get_cookie.php" method="post">
	
	<?php
	 include 'acad/model/select/campus.php'; ?>

	<input type="submit" value="Login">


</form>


</body>
</html>