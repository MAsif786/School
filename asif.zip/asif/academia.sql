-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2017 at 12:01 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `academia`
--

-- --------------------------------------------------------

--
-- Table structure for table `campus`
--

CREATE TABLE `campus` (
  `cmID` int(11) NOT NULL,
  `cmName` varchar(50) NOT NULL,
  `cmCity` varchar(50) NOT NULL,
  `cmAddress` varchar(50) NOT NULL,
  `cmContact` varchar(50) NOT NULL,
  `cmContact2` varchar(50) NOT NULL,
  `cmContactM` varchar(60) NOT NULL,
  `cmMail` varchar(50) NOT NULL,
  `cmEsatablishDate` date NOT NULL,
  `cmLastEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cmRoomCount` int(11) NOT NULL,
  `cmDocuments` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campus`
--

INSERT INTO `campus` (`cmID`, `cmName`, `cmCity`, `cmAddress`, `cmContact`, `cmContact2`, `cmContactM`, `cmMail`, `cmEsatablishDate`, `cmLastEdit`, `cmRoomCount`, `cmDocuments`) VALUES
(1, 'Cadet', 'Okara', 'fjgk k242', '0333456789', '0333456789', '0333456789', 'CADET@MAIL', '0000-00-00', '2017-01-16 18:14:33', 55, 'Test'),
(2, 'Madin Tul ILam', 'Okara', 'rtfs fuf 7u 9id iy348 49  7tfsf', '0333456789', '0333456789', '0333456789', '756@dfd', '0000-00-00', '2017-01-22 04:57:59', 36, 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `crsID` int(11) NOT NULL,
  `crsCode` varchar(100) NOT NULL,
  `crsName` varchar(50) NOT NULL,
  `tcID` int(11) NOT NULL,
  `cmID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`crsID`, `crsCode`, `crsName`, `tcID`, `cmID`) VALUES
(1, 'PHP101111', 'PHP Web Design and Development  ', 0, 1),
(2, 'QXB81FB528249', '10th Class', 1, 1),
(4, 'ISL2750UPT06WT3E', '', 0, 1),
(6, 'QXB81FB528249', '', 0, 1),
(7, 'ISL2750UPT06WT3E', '', 0, 1),
(8, '790069416057', '', 0, 1),
(9, '790069416057', '', 0, 1),
(10, 'Ilam-a-Iqbal', 'Matric(B)', 3, 1),
(11, '002-25', 'Matric(B)', 3, 1),
(12, '002-25', 'Matric(B)', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exmID` int(11) NOT NULL,
  `exmName` varchar(50) NOT NULL,
  `exmDate` date NOT NULL,
  `exmStatus` varchar(5) NOT NULL,
  `exmTimeStemp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cmID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exmID`, `exmName`, `exmDate`, `exmStatus`, `exmTimeStemp`, `cmID`) VALUES
(1, '', '0000-00-00', 'Open', '2017-01-22 05:19:43', 2),
(2, 'December Test', '0000-00-00', 'Open', '2017-01-22 05:23:47', 2),
(3, 'December Test', '0000-00-00', 'Open', '2017-01-22 05:38:02', 2);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `stID` int(11) NOT NULL,
  `stCode` varchar(22) NOT NULL,
  `stDep` varchar(50) NOT NULL,
  `stName` varchar(50) NOT NULL,
  `stFather` varchar(50) NOT NULL,
  `stDOB` date NOT NULL,
  `stCNIC` varchar(50) NOT NULL,
  `stContactP` varchar(50) NOT NULL,
  `stContactM` varchar(50) NOT NULL,
  `stMailP` varchar(50) NOT NULL,
  `stMailO` varchar(50) NOT NULL,
  `stRefName` varchar(50) NOT NULL,
  `stRefContact` varchar(50) NOT NULL,
  `cmID` int(11) NOT NULL,
  `stLastEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `stDocument` varchar(300) NOT NULL,
  `salary` int(11) NOT NULL,
  `incrementPer` int(11) NOT NULL,
  `stAddress` text NOT NULL,
  `stHireDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`stID`, `stCode`, `stDep`, `stName`, `stFather`, `stDOB`, `stCNIC`, `stContactP`, `stContactM`, `stMailP`, `stMailO`, `stRefName`, `stRefContact`, `cmID`, `stLastEdit`, `stDocument`, `salary`, `incrementPer`, `stAddress`, `stHireDate`) VALUES
(1, '1001', 'admin', 'Muhammad Asif', 'Azam Ali', '0000-00-00', '3110-16922497-5', '03036982822', '03036982800', 'snew3110@gmail.com', '', 'Ali', '', 2, '2017-01-23 05:02:03', '../document/staff/160774_bugatti_galibier_concept.jpg', 0, 0, '34sdvsd5 43dwewr', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `stdattendance`
--

CREATE TABLE `stdattendance` (
  `satID` int(11) NOT NULL,
  `stdID` int(11) NOT NULL,
  `attendance` tinyint(4) NOT NULL,
  `satdate` date NOT NULL,
  `satTime` time NOT NULL,
  `comments` text NOT NULL,
  `cmID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stdID` int(11) NOT NULL,
  `stdCode` varchar(22) NOT NULL,
  `stdRollNo` varchar(50) NOT NULL,
  `stdName` varchar(50) NOT NULL,
  `crsID` varchar(50) NOT NULL,
  `stdFather` varchar(50) NOT NULL,
  `stdCNIC` varchar(50) NOT NULL,
  `stdContactP` varchar(18) NOT NULL,
  `stdContactHome` varchar(18) NOT NULL,
  `stdDOB` date NOT NULL,
  `stdDocument` varchar(300) NOT NULL,
  `stdFees` int(11) NOT NULL,
  `stdAddress` text NOT NULL,
  `stdAdmissionDate` date NOT NULL,
  `stdRef` varchar(50) NOT NULL,
  `stdStatus` varchar(50) NOT NULL,
  `stdStatusChangeDate` date NOT NULL,
  `stdLastEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cmID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stdID`, `stdCode`, `stdRollNo`, `stdName`, `crsID`, `stdFather`, `stdCNIC`, `stdContactP`, `stdContactHome`, `stdDOB`, `stdDocument`, `stdFees`, `stdAddress`, `stdAdmissionDate`, `stdRef`, `stdStatus`, `stdStatusChangeDate`, `stdLastEdit`, `cmID`) VALUES
(1, '1001', '1234', 'Muhammad Asif', '10', 'Azam Ali', '31101-6920497-5', '3422342424', '03036982800', '0000-00-00', '../document/student/29.jpg', 20000, 'Mehboob Town Okara', '0000-00-00', '3423424rvsd', 'Enrolled', '0000-00-00', '2017-01-23 05:01:52', 2),
(2, '', '232', 'Saqib Ali', '2', 'Azam Ali', '31101-6920497-5', '3422342424', '03036982800', '0000-00-00', 'document/student/_still_life-1552702.jpg', 20000, 'Mehboob Town Okara', '0000-00-00', '3423424rvsd', 'Enrolled', '0000-00-00', '2017-01-23 08:37:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tcattendance`
--

CREATE TABLE `tcattendance` (
  `tatID` int(11) NOT NULL,
  `tcID` int(11) NOT NULL,
  `attendance` tinyint(4) NOT NULL,
  `tatdate` date NOT NULL,
  `tatTime` time NOT NULL,
  `comments` text NOT NULL,
  `cmID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tcattendance`
--

INSERT INTO `tcattendance` (`tatID`, `tcID`, `attendance`, `tatdate`, `tatTime`, `comments`, `cmID`) VALUES
(1, 0, 1, '2017-01-22', '16:04:30', '', 2),
(2, 1, 1, '2017-01-22', '16:07:36', '', 2),
(3, 1, 0, '2017-01-22', '16:08:00', '', 2),
(4, 1, 1, '2017-01-22', '16:08:12', '', 2),
(5, 2, 1, '2017-01-22', '16:08:56', '', 2),
(6, 2, 0, '2017-01-22', '16:09:23', '', 2),
(7, 2, 1, '2017-01-22', '16:09:51', '', 2),
(8, 3, 0, '2017-01-22', '16:10:03', '', 2),
(9, 3, 1, '2017-01-22', '16:10:10', '', 2),
(10, 0, 0, '2017-01-23', '08:26:41', '', 0),
(11, 0, 1, '2017-01-23', '08:26:51', '', 0),
(12, 2, 0, '2017-01-23', '08:27:00', '', 0),
(13, 2, 1, '2017-01-23', '08:27:15', '', 0),
(14, 2, 0, '2017-01-23', '08:27:56', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `tsID` int(11) NOT NULL,
  `exmID` int(11) NOT NULL,
  `tsDate` date NOT NULL,
  `tsName` varchar(50) NOT NULL,
  `tcID` int(11) NOT NULL,
  `crsID` int(11) NOT NULL,
  `tsTotalMarks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`tsID`, `exmID`, `tsDate`, `tsName`, `tcID`, `crsID`, `tsTotalMarks`) VALUES
(1, 2, '0000-00-00', 'Math', 3, 2, 68),
(2, 2, '0000-00-00', 'Math', 3, 2, 68),
(3, 2, '2016-07-08', 'Math', 3, 2, 68),
(4, 2, '0000-00-00', 'uy', 3, 2, -16);

-- --------------------------------------------------------

--
-- Table structure for table `testresult`
--

CREATE TABLE `testresult` (
  `rsID` int(11) NOT NULL,
  `stdID` int(11) NOT NULL,
  `rsObtainMarks` int(11) NOT NULL,
  `tsID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `campus`
--
ALTER TABLE `campus`
  ADD PRIMARY KEY (`cmID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`crsID`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`exmID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`stID`),
  ADD UNIQUE KEY `stCode` (`stCode`);

--
-- Indexes for table `stdattendance`
--
ALTER TABLE `stdattendance`
  ADD PRIMARY KEY (`satID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stdID`),
  ADD UNIQUE KEY `stdCode` (`stdCode`);

--
-- Indexes for table `tcattendance`
--
ALTER TABLE `tcattendance`
  ADD PRIMARY KEY (`tatID`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`tsID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `campus`
--
ALTER TABLE `campus`
  MODIFY `cmID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `crsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `exmID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `stID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stdattendance`
--
ALTER TABLE `stdattendance`
  MODIFY `satID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stdID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tcattendance`
--
ALTER TABLE `tcattendance`
  MODIFY `tatID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `tsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
