<?php 

$id = $_POST['cm'];

setcookie('cmID', $id, time() + (86400 * 30), "/"); // 86400 = 1 day

header("Location: acad/index.php")

 ?>